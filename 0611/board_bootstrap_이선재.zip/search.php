<?php
  //글목록을 출력하기 위한 문서
  include('./php/dbconn.php');
  
  $range = $_POST['search_range'];
  $search = trim($_POST['search']);
?>

<!DOCTYPE html>
<html lang="ko">
  <head>
    <title>자유게시판 - 검색결과</title>
  <style>
    .free_board tr th:first-child{width:6%; text-align:center;}
    .free_board tr th:nth-child(2){width:72%;}
    .free_board tr th:nth-child(3){width:13%;}
    .free_board tr th:last-child{width:13%;}
    .free_board a{color:#333; text-decoration:none;}
    .free_board a:hover{text-decoration:underline;}
  </style>


<!-- 헤더 삽입 -->
<?php include('./header.php') ?>

    <section class="free_board_wrap container">
      <form name="search" method="post" action="search.php">
        <h2 class="text-center">자유게시판 <?php echo $search ?> 검색결과</h2>
        <table class="free_board table table-striped table-hover">
          <caption class="d-none">자유게시판 검색결과</caption>
          <thead class="table-dark">
            <tr>
              <th scope="row">NO.</th>
              <th>제목</th>
              <th>글쓴이</th>
              <th>작성일</th>
            </tr>
          </thead>
          <tbody>
            <?php

              if($range=='제목'){
                $sql = "select id, subject, name, date(datetime) from free_board where subject like '%".$search."%' order by id desc";
                // echo $sql;
              }else if($range=='글쓴이'){
                $sql = "select id, subject, name, date(datetime) from free_board where name like '%".$search."%' order by id desc";
              }else if($range=='내용'){
                $sql = "select id, subject, name, date(datetime) from free_board where memo like '%".$search."%' order by id desc";
              }else{
                $sql = "select id, subject, name, date(datetime) from free_board where subject like '%".$search."%' or memo like '%".$search."%' order by id desc";
              }

              $result = mysqli_query($conn, $sql);
              
              // datetime을 년월일만 불러오는 여러 방법(출력시 적용)
              // substr($row['datetime'],0,10)
              // date("Y-m-d", strtotime($row['datetime']))

              while($row = mysqli_fetch_row($result)){
                print "<tr><td scope='row'>".$row[0]."</td>".
                    "<td><a href='view.php?id=".$row[0]."' title='".$row[1]."'>".$row[1]."</a></td>".
                    "<td>".$row[2]."</td>".
                    "<td>".$row[3]."</td></tr>";
              };
            ?>
              <!-- <?php
              while($row = mysqli_fetch_array($result)){
              ?>
                <tr>
                  <td><?=$row['id'] ?></td>
                  <td><a href="view.php?id=<?=$row['id'] ?>" title="<?=$row['subject'] ?>"><?=$row['subject'] ?></a></td>
                  <td><?=$row['name'] ?></td>
                  <td><?=$row['date(datetime)'] ?></td>
                </tr>
              <?php
              };
              ?> -->

              <!-- 안됨 -->
              <!-- <?php
              for($i=0; $row=mysqli_fetch_assoc($result); $i++):
              ?>
                <tr>
                  <td><?php echo $row['id'] ?></td>
                  <td><a href="view.php?id=<?php echo $row['id'] ?>" title="<?php echo $row['subject'] ?>"><?php echo $row['subject'] ?></a></td>
                  <td><?php echo $row['name'] ?></td>
                  <td><?php echo $row['datetime'] ?></td>
                </tr>
              <?php endfor; ?> -->
            <?php
              mysqli_free_result($result);
              mysqli_close($conn);
            ?>
          </tbody>
        </table>
        <p class="d-flex justify-content-between">
          <a href="./list.php" title="전체글보기" class="btn btn-primary">전체글보기</a>
          <a href="./write.php" title="글쓰기" class="btn btn-primary">글쓰기</a>
        </p>
        <fieldset class="input-group justify-content-center">
          <legend class="d-none">검색폼양식</legend>
          <label for="search_range" class="col-form-label me-2"> 검색범위 : </label>
          <select name="search_range" id="search_range" class="form-select" aria-label="검색범위 선택">
            <option value="제목">제목</option>
            <option value="글쓴이">글쓴이</option>
            <option value="내용">내용</option>
            <option value="제목+내용">제목+내용</option>
          </select>
          <label for="search" class="col-form-label ms-3 me-2"> 검색어 : </label>
          <input type="search" id="search" name="search" class="form-control" required maxlength="255" placeholder="검색어 입력">
          <input type="submit" value="검색" id="search_btn" class="btn btn-secondary">
        </fieldset>
      </form>
    </section>
    <script>
      const s_btn = document.getElementById('search_btn');

      function form_check(){
        // alert('함수');
        if(document.getElementById('search').value.trim().length<1){
          alert('검색어를 입력하지 않았습니다. 확인하세요.');
          event.preventDefault();
        }
        return true;
      }

      s_btn.addEventListener('click',function(){
        // alert('test');
        form_check();
      })

    </script>
  </body>
</html>