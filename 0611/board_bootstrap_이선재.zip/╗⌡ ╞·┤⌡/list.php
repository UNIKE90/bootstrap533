    <?php
      include('./php/db_conn.php');
      include('./php/header.php');
    ?>

    <form name="검색하기" method="post" action="./list_search.php">
    <table class="free_board">
      <caption>게시판 목록</caption>
        <tr>
          <th>NO.</th>
          <th>제목</th>
          <th>작성자</th>
          <th>날짜</th>
        </tr>

      <?php
        $num = 50;
        //한 페이지에 보여질 게시물 개수
        $list_num = 5;
        
        //이전, 다음 버튼 클릭시 나오는 페이지 수
        $page_num =3;
        
        //현재 페이지
        $page = isset($_GET["page"])? $_GET["page"] : 1;
        
        // 전체페이지수 계산
        $total_page = ceil($num / $list_num);
        //10페이지 = 게시물 50개 / 5 한페이지 출력개수
        
        //전체블럭 계산
        $total_block = ceil($total_page / $page_num);
        //3.333333 =  10/3
        
        //현재블럭번호 계산
        $now_block = ceil($page / $page_num);
        
        //블럭당 시작페이지 번호
        $s_pageNum = ($now_block - 1) * $page_num + 1;
        
        //데이터가 0인 경우
        if($s_pageNum <= 0){ $s_pageNum = 1; };
        
        //블럭당 마지막페이지 번호
        $e_pageNum = $now_block * $page_num;
        
        //마지막 번호가 전체 페이지번호보다 크다면 동일한 값을 준다.
        if($e_pageNum > $total_page){ $e_pageNum = $total_page; };

        $start = ($page - 1) * $list_num;
        $cnt = $start + 1;      

        $query = "select * from free_board limit $start, $list_num;";
        $result = mysqli_query($conn, $query);
        
        //반복문 while
        while($row = mysqli_fetch_array($result)){
      ?>
      
      <tr>
          <td><?=$row['id']?></td>
          <td><a href="view.php?id=<?=$row['id']?>" title="<?=$row['memo']?>">
              <?=$row['memo']?>
            </a></td>
          <td><?=$row['subject']?></td>
          <td>
            <?=date("Y-m-d",strtotime($row['datetime']))?>
          </td>
          <!--substr($date['datetime'],0,10)-->
      </tr>
            
      <?php
          }
            $cnt++;


          mysqli_free_result($result);
          mysqli_close($conn);
      ?>
    </table>
    <p>
      <?php 
        //페이지네이션이 들어가는 곳
        //이전페이지
        if($page <= 1){ ?> 
          <a href="list.php?page=1">이전</a> 
          <?php } 
          else{ ?> 
          <a href="list.php?page=<?php echo ($page-1); ?>">이전</a>
          <?php };
          ?> 
      <?php //여기서부터 페이지 번호출력하기
        for($print_page=$s_pageNum;$print_page<=$e_pageNum;$print_page++){?>
          <a href="list.php?page=<?php echo $print_page; ?>">
            <?php echo $print_page ?>
          </a>
        <?php }; ?>  

        <!-- 다음 버튼 나오는 곳 -->
        <?php if($page>=$total_page){ ?>
          <a href="list.php?page=<?php echo $total_page; ?>" title="다음페이지로">다음</a>
        <?php }else{ ?>
          <a href="list.php?page=<?php echo ($page+1); ?>">다음</a>
      <?php };    
      ?>    
    </p>
    <p>
      <input type="search" id="search" name="search">
      <input type="submit" value="검색(제목 + 내용)" id="search_btn" >
      <a href="./write.php" title="글쓰기">글쓰기</a>
    </p>
    </form>
  </main>

  <script>
    let s_btn = document.getElementById('search_btn');
    s_btn.addEventListener('click', function(){
      console.log('click');
      form_check();
    });
    
    function form_check(){
      //alert('검색어를 입력하지 않았습니다.')
      if(document.getElementById('search').value.length<1){
        alert('검색어를 입력하지 않았습니다. 확인하세요');
        return false;
      }
      return true;
    }

  </script>
</body>
</html>

