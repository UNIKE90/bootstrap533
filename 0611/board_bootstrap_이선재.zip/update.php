<?php
  include('./php/dbconn.php'); //db계정과 연결
  
  $id = $_POST['id'];
  $id = mysqli_real_escape_string($conn, $id);
  $pwd = $_POST['pwd'];
  $pwd = mysqli_real_escape_string($conn, $pwd);

  $sql = "select * from free_board where id='$id'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_array($result);

  // echo $row[0].'<br>';
  // echo $row[1].'<br>';
  // echo $row[2].'<br>';
  // echo $row[3].'<br>';
  // echo $row[4].'<br>';
  // echo $row[5].'<br>';

  if(!password_verify($pwd, $row[4])){
    echo "<script>alert('패스워드가 일치하지 않습니다. 다시 확인하세요.');</script>";
    echo "<script>history.back(1);</script>"; //이전화면으로 돌아가기
  }
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <title>게시글 수정하기</title>
    
    <!-- 헤더 삽입 -->
    <?php include('./header.php') ?>

  <section class="board container">
  <h2 class="text-center">게시글 수정하기</h2>
    <table class="form_wrap table">
      <caption class="d-none">게시글 수정하기</caption>
      <form name="글수정하기" method="post" action="./php/updateinput.php" onsubmit="return formCheck();">
      <thead>
        <tr>
        <tr>
          <td scope="row">
            <label for="title">글제목</label>
          </td>
          <td>
            <input type="text" id="title" name="title" required maxlength="255" placeholder="제목을 입력하세요." value="<?php echo $row[1] ?>" class="form-control">
          </td>
      </thead>
      <tbody>
        <tr>
          <td scope="row">
            <label for="name">작성자</label>
          </td>
          <td>
            <input type="text" id="name" name="name" required maxlength="50" placeholder="이름을 입력하세요." value="<?php echo $row[2] ?>" readonly class="form-control">
          </td>
        </tr>
        <tr>
          <td>
            <label for="pwd">비밀번호</label>
          </td>
          <td>
            <input type="password" id="pwd" name="pwd" required maxlength="255" placeholder="비밀번호를 입력하세요." autoComplete="off" class="form-control">
          </td>
        </tr>
        <tr>
          <td scope="row">
            <label for="txtbox">내용</label>
          </td>
          <td>
            <textarea cols="50" rosw="30" id="txtbox" name="txtbox" required maxlength="255" placeholder="내용을 입력하세요." class="form-control" style="height:200px;"><?php echo $row[3] ?></textarea>
          </td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="2" scope="row" class="text-center">
            <input type="hidden" name="id" value="<?php echo $row[0] ?>">
            <input type="submit" value="글수정 완료" class="btn btn-success">
            <input type="reset" value="입력 취소" class="btn btn-secondary">
          </td>
        </tr>
      </tfoot>
      </form>
    </table>
  </section>
  <script>
      console.log(document.getElementById('name').value.length);
    function formCheck(){
      // alert('test');
      //작성자명 체크
      if(document.getElementById('name').value.trim().length<1){
        alert('작성자명을 입력하세요.');
        return false;
      }
      //제목 체크
      if(document.getElementById('title').value.trim().length<1){
        alert('제목을 입력하세요.');
        return false;
      }
      //내용 체크
      if(document.getElementById('txtbox').value.trim().length<1){
        alert('내용을 입력하세요.');
        return false;
      }
      //패스워드 체크
      if(document.getElementById('pwd').value.trim().length<1){
        alert('패스워드를 입력하세요.');
        return false;
      }
      return true;
    }
  </script>
</body>
</html>