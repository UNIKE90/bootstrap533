  <footer>
    <address class="text-center">
      Copyright&copy;2024 free board all rights reserved.
    </address>
  </footer>
</body>
</html>