<?php
  include('./php/dbconn.php'); //db계정과 연결
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <title>자유게시판 - 글쓰기</title>
    <!-- 헤더 삽입 -->
    <?php include('./header.php') ?>

  <section class="board text-center">
  <h2>게시판 글입력</h2>
    <table class="free_board form_wrap container table">
      <caption class="d-none">게시판 글쓰기</caption>
      <form name="글쓰기" method="post" action="./php/dbinput.php" onsubmit="return formCheck();">
      <thead>
        <tr class="border-top">
          <td scope="row">
            <label for="title">글제목</label>
          </td>
          <td>
            <input type="text" id="title" name="title" class="form-control" required maxlength="255" placeholder="제목을 입력하세요.">
          </td>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td scope="row">
            <label for="name">작성자</label>
          </td>
          <td>
            <input type="text" id="name" name="name" class="form-control" required maxlength="50" placeholder="이름을 입력하세요.">
          </td>
        </tr>
        <tr>
          <td>
            <label for="pwd">비밀번호</label>
          </td>
          <td>
            <input type="password" id="pwd" name="pwd" class="form-control" required maxlength="255" placeholder="비밀번호를 입력하세요.">
          </td>
        </tr>
        <tr>
          <td scope="row">
            <label for="txtbox">내용</label>
          </td>
          <td>
            <textarea cols="50" rows="15" id="txtbox" name="txtbox" class="form-control" required maxlength="255" placeholder="내용을 입력하세요."></textarea>
          </td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="2" scope="row" class="border-bottom-0">
            <input type="submit" value="글입력 완료" class="btn btn-primary">
            <input type="reset" value="입력 취소" class="btn btn-secondary">
          </td>
        </tr>
      </tfoot>
      </form>
    </table>
  </section>
  <script>
      console.log(document.getElementById('name').value.length);
    function formCheck(){
      // alert('test');
      //작성자명 체크
      if(document.getElementById('name').value.trim().length<1){
        alert('작성자명을 입력하세요.');
        return false;
      }
      //제목 체크
      if(document.getElementById('title').value.trim().length<1){
        alert('제목을 입력하세요.');
        return false;
      }
      //내용 체크
      if(document.getElementById('txtbox').value.trim().length<1){
        alert('내용을 입력하세요.');
        return false;
      }
      //패스워드 체크
      if(document.getElementById('pwd').value.trim().length<1){
        alert('패스워드를 입력하세요.');
        return false;
      }
      return true;
    }
  </script>
    <?php include('./footer.php') ?>