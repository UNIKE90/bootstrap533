<!-- delete.php -->
<?php
  include('./dbconn.php'); //db연결하기

  $id = $_POST['id'];
  $id = mysqli_real_escape_string($conn, $id);
  $pwd = $_POST['pwd'];
  $pwd = mysqli_real_escape_string($conn, $pwd);
  
  $sql = "select * from free_board where id='$id'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_row($result);
  //사용자가 입력한 패스워드
  // echo "<script>alert(".$pwd.");</script>";
  // echo "<script>alert(".$row[4].");</script>";
  // echo $pwd;
  // echo $row[4]; //데이터베이스에 있는 패스워드

  //만약에 넘겨받은 패스워드가 일치하면 삭제
  if(password_verify($pwd, $row[4])){
    $sql = "delete from free_board where id='$id'";
    mysqli_query($conn, $sql);

    //삭제하고 list화면으로 이동하기
    echo "<script>alert('정상적으로 삭제되었습니다.');location.replace('../list.php');</script>";
  }else{//일치하지 않으면
    //패스워드가 일치하지 않습니다. 다시 확인하세요.
    echo "<script>alert('패스워드가 일치하지 않습니다. 다시 확인하세요.');</script>";
    // echo "<script>alert(".$id.");</script>";
    //이전페이지로 이동.
    // echo "<script>location.replace('../view.php?id=".$id."');</script>";
    echo "<script>history.back(1);</script>"; //이전화면으로 돌아가기
    exit;
  }

?>