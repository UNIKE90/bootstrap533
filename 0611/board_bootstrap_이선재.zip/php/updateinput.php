<?php
  include('./dbconn.php'); //db계정과 연결

  $id = $_POST['id'];
  $id = mysqli_real_escape_string($conn, $id);
  $pwd = $_POST['pwd'];
  $pwd = mysqli_real_escape_string($conn, $pwd);

  $sql = "select * from free_board where id='$id'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);

  if(!password_verify($pwd, $row['pwd'])){
    echo "<script>alert('패스워드가 일치하지 않습니다. 다시 확인하세요.');</script>";
    echo "<script>location.replace('../view.php?id=".$id."');</script>";
  }

  // echo $id;

  $subject = $_POST['title'];
  $subject = mysqli_real_escape_string($conn, $subject);
  $memo = $_POST['txtbox'];
  $memo = mysqli_real_escape_string($conn, $memo);

  $sql = "update free_board set subject='$subject', memo='$memo' where id='$id'";
  $result = mysqli_query($conn, $sql);

  if(!$result){
    echo "수정 실패 : ".mysqli_error($conn);
  }else{
    echo "<script>alert('수정이 완료되었습니다.');</script>";
    echo "<script>location.replace('../view.php?id=".$id."');</script>";
  }
?>