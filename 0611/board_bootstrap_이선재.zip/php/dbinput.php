<!-- dbinput.php -->
<?php
  include('./dbconn.php'); //db연결
  
  // phpinfo();

  $id = $_POST["id"];
  $title = $_POST["title"];
  $name = $_POST["name"];
  //nl2br : 데이터 입력시 텍스트 정보는 그대로 입력되고, 출력시에만 br태그 사용한 것처럼 자동 줄변경이 됨.
  $txtbox = $_POST["txtbox"];
  $pwd = $_POST["pwd"];

  $id = mysqli_real_escape_string($conn, $id);
  $title = mysqli_real_escape_string($conn, $title);
  $name = mysqli_real_escape_string($conn, $name);
  $txtbox = mysqli_real_escape_string($conn, $txtbox);
  $pwd = mysqli_real_escape_string($conn, $pwd);

  date_default_timezone_set('Asia/Seoul');
  $datetime = date('Y-m-d H:i:s');

  //값 출력하기
  // echo $id;
  // echo $title;
  // echo $name;
  // echo $txtbox;
  // echo $pwd;
  // echo $datetime;

  //사용자 아이피주소
  $ip = $_SERVER['SERVER_ADDR']; //사용자가 접속한 IP주소를 가져옴.

  // echo $ip;

  //만약에 '수정'버튼을 클릭한 경우 update구문을 작성하고
  if($id){ //사용자가 수정한 아이디 값이 같을 경우
    $sql = "select * from free_board where id='$id'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);

    if(password_verify($pwd,row[pwd])){
      echo "<script>alert('패스워드가 다릅니다. 다시 확인하세요.')</script>";
      exit;
    }else{
      $sql = "update free_board set name = '$name', subject='$title', memo='$txtbox' where id='$id'";
      mysqli_query($conn, $sql);
    }
  }else{
    //새로 글을 등록하고자 하는 경우는 아래 쿼리문을 실행한다.
    //DB INSERT문을 사용하여 데이터에 자료 입력하기

    //패스워드 암호화
    $pwd = password_hash($pwd, PASSWORD_DEFAULT);

    $sql = "insert into free_board(subject, name, memo, pwd, datetime, ip)  value('$title','$name','$txtbox','$pwd','$datetime','$ip')";

    $result = mysqli_query($conn, $sql);

    if($result){
      echo "<script>alert('글작성이 완료되었습니다.');</script>";
      echo "<script>location.replace('../list.php');</script>";
      exit;
    }else{
      echo "글입력 실패 : " .mysqli_error($conn);
      mysqli_close($conn);
    }
  }

  // header('Location: ../list.php');
?>