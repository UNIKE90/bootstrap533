<?php
  include('./php/dbconn.php'); //db연결하기

  $id = $_GET['id'];
  $id = mysqli_real_escape_string($conn, $id);

  // echo $id; //넘겨받은 id값 출력해보기

  $sql = "select * from free_board where id='$id'";
  $result = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="ko">
  <head>
    <title>글내용 보기</title>
    <style>
      th{width: 20%;}
    </style>
    
    <!-- 헤더 삽입 -->
    <?php include('./header.php') ?>

    <main>
      <section class="container">
        <h2 class="text-center">글내용 보기</h2>
        <table class="table">
          <caption class="d-none">글내용 보기</caption>
          <tbody>
            <tr>
              <th>No.</th><td><?php echo $row['id'] ?></td>
            </tr>
            <tr>
              <th>작성자</th><td><?php echo $row['name'] ?></td>
            </tr>
            <tr>
              <th>제목</th><td><?php echo $row['subject'] ?></td>
            </tr>
            <tr>
              <th>내용</th><td><?php echo nl2br($row['memo']) ?></td>
            </tr>
            <tr>
              <th>작성일</th><td><?php echo substr($row['datetime'],0,10) ?></td>
            </tr>
          </tbody>
        </table>
          <a href="./list.php" title="글목록으로 돌아가기" class="btn btn-primary">목록보기</a>
          <form name="삭제수정" method="post" class="text-center">
            <label for="pwd">비밀번호 입력 : </label>
            <input type="password" name="pwd" id="pwd" class="form-control-sm">
            <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
            <input type="submit" value="삭제하기" id="delete" formaction="./php/delete.php" onclick="return f_check()" class="btn btn-danger">
            <input type="submit" value="수정하기" id="update" formaction="./update.php" onclick="return f_check()" class="btn btn-success">
          </form>
      </section>
    </main>
    <script>
      function f_check(){
        // alert('test');
        if(document.getElementById('pwd').value.length<1){
          alert('비밀번호를 입력해 주세요.');
          return false;
        }
      }
    </script>
  </body>
</html>